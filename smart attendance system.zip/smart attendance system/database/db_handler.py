import sqlite3
from datetime import datetime
from config import DATABASE_PATH

conn = sqlite3.connect(DATABASE_PATH)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS students(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    roll TEXT UNIQUE
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS attendance(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll TEXT,
    date TEXT,
    time TEXT
)
""")
conn.commit()

def add_student(name, roll):
    cursor.execute("INSERT OR IGNORE INTO students(name, roll) VALUES (?,?)", (name, roll))
    conn.commit()

def mark_attendance(roll):
    today = datetime.now().strftime("%Y-%m-%d")
    now_time = datetime.now().strftime("%H:%M:%S")

    cursor.execute("SELECT * FROM attendance WHERE roll=? AND date=?", (roll, today))
    result = cursor.fetchone()

    if result is None:
        cursor.execute("INSERT INTO attendance(roll, date, time) VALUES (?,?,?)",
                       (roll, today, now_time))
        conn.commit()
        print(f"Attendance Marked for {roll}")
    else:
        print("Attendance already marked today")
