import face_recognition
import numpy as np

def recognize_face(known_encodings, known_rolls, frame):
    rgb = frame[:, :, ::-1]
    faces = face_recognition.face_locations(rgb)
    encodings = face_recognition.face_encodings(rgb, faces)

    for encoding in encodings:
        if len(known_encodings) == 0:
            return None

        matches = face_recognition.compare_faces(known_encodings, encoding)
        distances = face_recognition.face_distance(known_encodings, encoding)

        best_match_index = np.argmin(distances)

        if matches[best_match_index]:
            return known_rolls[best_match_index]

    return None
