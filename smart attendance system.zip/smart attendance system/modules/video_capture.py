import cv2
import time

def capture_10sec_video(cap, roll, dataset_path):
    start_time = time.time()
    count = 0

    while time.time() - start_time < 10:
        ret, frame = cap.read()
        cv2.imshow("Registering...", frame)

        cv2.imwrite(f"{dataset_path}/{roll}/{count}.jpg", frame)
        count += 1

        if cv2.waitKey(1) == 27:
            break

    cv2.destroyWindow("Registering...")
