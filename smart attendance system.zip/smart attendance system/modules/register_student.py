import os
from modules.video_capture import capture_10sec_video
from modules.face_encoder import generate_encoding, save_encodings
from database.db_handler import add_student
from config import DATASET_PATH

def register_student(cap, known_encodings, known_rolls):
    name = input("Enter Student Name: ")
    roll = input("Enter Roll Number: ")

    os.makedirs(f"{DATASET_PATH}/{roll}", exist_ok=True)

    print("Capturing video for 10 seconds...")
    capture_10sec_video(cap, roll, DATASET_PATH)

    image_path = f"{DATASET_PATH}/{roll}/0.jpg"
    encoding = generate_encoding(image_path)

    if encoding is not None:
        known_encodings.append(encoding)
        known_rolls.append(roll)
        save_encodings(known_encodings, known_rolls)
        add_student(name, roll)
        print("Registration Successful!")
    else:
        print("Face not detected properly. Try again.")
