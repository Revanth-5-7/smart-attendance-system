from database.db_handler import mark_attendance

def process_attendance(roll):
    if roll:
        mark_attendance(roll)
