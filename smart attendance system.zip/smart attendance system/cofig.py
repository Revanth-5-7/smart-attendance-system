import os

DATASET_PATH = "dataset"
ENCODING_PATH = "encodings/face_data.pkl"
DATABASE_PATH = "attendance.db"

os.makedirs(DATASET_PATH, exist_ok=True)
os.makedirs("encodings", exist_ok=True)
