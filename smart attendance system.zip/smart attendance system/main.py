import cv2
from modules.face_encoder import load_encodings
from modules.recognizer import recognize_face
from modules.register_student import register_student
from modules.attendance_manager import process_attendance

cap = cv2.VideoCapture(0)

known_encodings, known_rolls = load_encodings()

print("Smart Attendance System Started...")

while True:
    ret, frame = cap.read()

    roll = recognize_face(known_encodings, known_rolls, frame)

    if roll:
        process_attendance(roll)
    else:
        print("Unknown Face Detected")
        register_student(cap, known_encodings, known_rolls)

    cv2.imshow("Smart Attendance System", frame)

    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
